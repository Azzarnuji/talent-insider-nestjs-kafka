# NestJS Kafka Outbox Module

Modul NestJS untuk mengimplementasikan **Outbox Pattern** dengan Kafka. Modul ini memastikan pesan tetap terkirim meskipun broker Kafka sedang down atau mengalami masalah koneksi dengan menyimpan pesan secara lokal terlebih dahulu.

## Fitur Utama
- **Agnostic Storage**: Mendukung **File System** (JSON) dan **Database** (TypeORM).
- **Flexible Scheduling**: Polling worker bisa menggunakan **Interval** (ms) atau **Cron Expression**.
- **TypeORM Hook Support**: Otomatis kirim event via `EntitySubscriber` tanpa mengubah logic di Service.
- **Reliable Relay**: Dilengkapi dengan mekanisme pengulangan (retry) otomatis jika Kafka down.

## Instalasi

```bash
# Install dari local tarball (sampai dipublish ke registry)
npm install /path/to/talent-insider-nestjs-kafka-1.0.0.tgz

# Atau via git (jika sudah di push)
npm install username/repository-name
```

> [!NOTE]
> Modul ini mendukung NestJS versi **8, 9, 10, dan 11**.

## Penggunaan

### Automated Migrations
You can use migrations instead of `synchronize: true`. We provide a CLI tool to publish the necessary migration files to your project:

```bash
# Untuk UUID
npx talent-insider-nestjs-kafka migrations uuid

# Untuk Auto-Increment (INT)
npx talent-insider-nestjs-kafka migrations increment
```
Command ini akan meng-copy file migration dengan **timestamp terbaru** dan menyesuaikan nama class-nya secara otomatis ke folder yang ditentukan (misal folder `migrations`).

Setelah itu, tambahkan migrations tersebut ke `AppModule`:

### 1. Registrasi Module

Daftarkan modul di `AppModule`. Anda bisa memilih menggunakan File Storage atau Database.

#### Contoh dengan TypeORM (Database):
```typescript
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { 
  KafkaOutboxModule, 
  IOutboxRepository, 
  TypeORMOutboxRepository, 
  OutboxEntity 
} from 'talent-insider-nestjs-kafka';
import { DataSource } from 'typeorm';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite', // atau postgres, mysql, dll
      database: 'database.sqlite',
      entities: [OutboxEntity],
      synchronize: true,
    }),
    KafkaOutboxModule.register({
      kafkaConfig: {
        brokers: ['localhost:9092'],
      },
      topic: 'main-outbox-topic', // Topic global di level module
      repository: {
        provide: IOutboxRepository,
        useFactory: (dataSource: DataSource) => {
          return new TypeORMOutboxRepository(dataSource.getRepository(OutboxEntity));
        },
        inject: [DataSource],
      },
      workerOptions: {
        use: 'cron', // atau 'interval'
        cronExpression: '*/10 * * * * *', // Setiap 10 detik
        batchSize: 10,
      },
    }),
    // Contoh dengan idType 'increment' dan OutboxIntEntity
    // Pastikan untuk mengimpor OutboxIntEntity dari 'talent-insider-nestjs-kafka'
    // dan menambahkannya ke daftar entities di TypeOrmModule.forRoot
    // entities: [OutboxEntity, OutboxIntEntity],
    KafkaOutboxModule.register({
      kafkaConfig: { brokers: ['localhost:9092'] },
      topic: 'main-outbox-topic',
      idType: 'increment', // 'uuid' (default) or 'increment'
      enableLog: true,     // Optional: set to false to disable library logs
      repository: {
        provide: IOutboxRepository,
        useFactory: (dataSource: DataSource) => {
          // Use OutboxEntity for 'uuid' idType
          // Use OutboxIntEntity for 'increment' idType
          const repo = dataSource.getRepository(OutboxIntEntity);
          return new TypeORMOutboxRepository(repo as any);
        },
        inject: [DataSource],
      },
      workerOptions: {
        use: 'interval',
        interval: 5000,
      },
    }),
  ],
})
export class AppModule {}
```

### 2. Manual Emit (via Service)

Gunakan `OutboxService` untuk mengirim pesan secara manual dari service Anda.

```typescript
@Injectable()
export class OrderService {
  constructor(private readonly outbox: OutboxService) {}

  async createOrder(data: any) {
    // ... simpan order ke DB utama ...

    // Simpan ke outbox (akan dikirim ke Kafka oleh worker)
    await this.outbox.emit('order-created', data, data.id);
  }
}
```

### 3. Automatic Emit (via TypeORM Subscriber)

Fitur ini memungkinkan Anda mengirim event otomatis setiap kali Entity tertentu disimpan, tanpa menyentuh kode Service.

**Buat Subscriber:**
```typescript
import { EventSubscriber } from 'typeorm';
import { AbstractOutboxSubscriber, OutboxService } from 'talent-insider-nestjs-kafka';
import { OrderEntity } from './order.entity';

@EventSubscriber()
export class OrderSubscriber extends AbstractOutboxSubscriber<OrderEntity> {
  listenTo() {
    return OrderEntity;
  }

  getEventType(entity: OrderEntity): string {
    return 'order.created';
  }

  // Optional: Transform payload sebelum dikirim
  preparePayload(entity: OrderEntity) {
    return {
      id: entity.id,
      type: 'CREATED',
      data: entity
    };
  }
}
```

**Daftarkan di AppModule:**
```typescript
providers: [OrderService, OrderSubscriber]
```

### 4. Global Subscriber (Auto-Detect All Entities)

Jika Anda ingin merekam perubahan **seluruh** entity secara otomatis tanpa membuat subscriber satu per satu:

1. Daftarkan `GlobalOutboxSubscriber` di `AppModule`:

```typescript
import { GlobalOutboxSubscriber } from 'talent-insider-nestjs-kafka';

@Module({
  // ... imports ...
  providers: [GlobalOutboxSubscriber],
})
export class AppModule {}
```

- Menggunakan nama entity sebagai `event_type` (misal: `order`, `user`, dsb).
- Membungkus payload dengan format standar yang sudah dikonfigurasi.

### Contoh Exclude Entity

```typescript
KafkaOutboxModule.register({
  // ...
  excludedEntities: [LogEntity, AuditEntity], // Bisa passing Class langsung
})
```

## Konfigurasi Modul

| Option | Deskripsi | Default |
| --- | --- | --- |
| `kafkaConfig` | Konfigurasi koneksi KafkaJS | `Required` |
| `topic` | Default topic untuk Kafka events | `Required` |
| `repository` | Provider repository (`TypeOrmOutboxRepository` / `FileSystemOutboxRepository`) | `Required` |
| `enableLog` | Menampilkan log debug di console | `true` |
| `idType` | Tipe data primary key outbox (`uuid` / `increment`) | `uuid` |
| `excludedEntities` | List nama entity yang ingin dikecualikan dari `GlobalOutboxSubscriber` | `[]` |
| `workerOptions` | Detil konfigurasi worker (lihat di bawah) | `Required` |

## Konfigurasi Worker

| Option | Deskripsi | Default |
| --- | --- | --- |
| `use` | Strategi polling: `interval` atau `cron` | `interval` |
| `interval` | Waktu tunggu antar polling (jika `use: interval`) | `5000` (ms) |
| `cronExpression` | Jadwal cron (jika `use: cron`) | - |
| `batchSize` | Jumlah pesan yang diproses sekali polling | `10` |

## Konfigurasi Cleanup

| Option | Deskripsi | Default |
| --- | --- | --- |
| `enable` | Mengaktifkan/menonaktifkan fitur cleanup | `false` |
| `use` | Strategi polling: `interval` atau `cron` | `interval` |
| `interval` | Waktu tunggu antar cleanup (jika `use: interval`) | `3600000` (1 jam) |
| `cronExpression` | Jadwal cron (jika `use: cron`) | - |
| `retentionDays` | Jumlah hari data `PROCESSED` disimpan sebelum dihapus | `0` (hapus langsung) |

## Dukungan UUID & Auto-Increment
## Author/Maintainer
- **Azzarnuji**

## Lisensi
MIT
