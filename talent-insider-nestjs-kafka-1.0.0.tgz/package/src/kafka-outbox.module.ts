import { DynamicModule, Module, Global, Provider } from "@nestjs/common";
import { Kafka, KafkaConfig } from "kafkajs";
import { OutboxService } from "./outbox.service";
import { OutboxWorker } from "./outbox.worker";
import { IOutboxRepository } from "./interfaces/outbox-repository.interface";

import { KafkaOutboxModuleOptions, KAFKA_OUTBOX_OPTIONS } from "./constants";

@Global()
@Module({})
export class KafkaOutboxModule {
  static register(options: KafkaOutboxModuleOptions): DynamicModule {
    if (!options.topic) {
      throw new Error(KafkaOutboxModule.name + " topic is required");
    }
    const optionsProvider: Provider = {
      provide: KAFKA_OUTBOX_OPTIONS,
      useValue: options,
    };

    const kafkaProvider: Provider = {
      provide: "KAFKA_INSTANCE",
      useValue: new Kafka(options.kafkaConfig),
    };

    const repositoryProvider: Provider = options.repository;

    return {
      module: KafkaOutboxModule,
      providers: [
        optionsProvider,
        kafkaProvider,
        repositoryProvider,
        OutboxService,
        OutboxWorker,
      ],
      exports: [OutboxService, KAFKA_OUTBOX_OPTIONS],
    };
  }
}
