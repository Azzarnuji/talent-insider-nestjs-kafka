import { Provider } from "@nestjs/common";
import { EntityClassOrSchema } from "@nestjs/typeorm/dist/interfaces/entity-class-or-schema.type";
import { KafkaConfig } from "kafkajs";

export interface KafkaOutboxModuleOptions {
  kafkaConfig: KafkaConfig;
  topic: string;
  repository: Provider;
  enableLog?: boolean;
  idType?: "uuid" | "increment";
  excludedEntities?: EntityClassOrSchema[];
  workerOptions: {
    use: "interval" | "cron";
    interval?: number;
    cronExpression?: string;
    batchSize?: number;
  };
  cleanupOptions?: {
    enable?: boolean;
    use: "interval" | "cron";
    interval?: number;
    cronExpression?: string;
    retentionDays?: number;
  };
}

export const KAFKA_OUTBOX_OPTIONS = "KAFKA_OUTBOX_OPTIONS";
