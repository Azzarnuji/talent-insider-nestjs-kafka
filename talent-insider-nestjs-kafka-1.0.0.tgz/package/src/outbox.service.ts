import { Injectable, Inject, Logger } from "@nestjs/common";
import { IOutboxRepository } from "./interfaces/outbox-repository.interface";
import { KAFKA_OUTBOX_OPTIONS, KafkaOutboxModuleOptions } from "./constants";

@Injectable()
export class OutboxService {
  constructor(
    @Inject(KAFKA_OUTBOX_OPTIONS)
    private readonly options: KafkaOutboxModuleOptions,
    @Inject(IOutboxRepository)
    private readonly repository: IOutboxRepository,
  ) {}

  async emit(topic: string | undefined, payload: any, key?: string) {
    const finalTopic = topic || this.options.topic;
    if (!finalTopic) {
      throw new Error(
        "Topic must be provided either in emit() or in KafkaOutboxModule options",
      );
    }

    const entryToSave = {
      topic: finalTopic,
      payload,
      key,
    };
    const savedEntry = await this.repository.save(entryToSave);
    if (this.options.enableLog !== false) {
      Logger.debug(
        `[OutboxService] Entry created: ${savedEntry.id} (status: PENDING)`,
        "OutboxService",
      );
    }
    return savedEntry;
  }
}
