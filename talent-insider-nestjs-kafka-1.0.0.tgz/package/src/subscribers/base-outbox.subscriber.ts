import {
  EntitySubscriberInterface,
  InsertEvent,
  UpdateEvent,
  DataSource,
  EventSubscriber,
} from "typeorm";
import { OutboxService } from "../outbox.service";
import { Logger } from "@nestjs/common";

@EventSubscriber()
export abstract class AbstractOutboxSubscriber<
  T,
> implements EntitySubscriberInterface<T> {
  protected readonly logger = new Logger(AbstractOutboxSubscriber.name);

  constructor(
    protected readonly dataSource: DataSource,
    protected readonly outboxService: OutboxService,
  ) {
    // Manually register if not handled by NestJS TypeOrmModule automatically
    if (this.dataSource && this.dataSource.subscribers) {
      const isAlreadyRegistered = this.dataSource.subscribers.some(
        (s) => s.constructor === this.constructor,
      );
      if (!isAlreadyRegistered) {
        this.dataSource.subscribers.push(this);
      }
    }
  }

  abstract listenTo(): any;

  /**
   * Override this to define the event type (e.g., 'order.created').
   * Default implementation returns 'entityname.action'.
   */
  getEventType(
    entityName: string,
    entity: T,
    action: "created" | "updated" | "deleted",
  ): string {
    return `${entityName.toLowerCase()}.${action}`;
  }

  /**
   * Override this to define the message key (optional)
   */
  getKey(entity: T): string | undefined {
    return (entity as any).id?.toString();
  }

  /**
   * Override this to transform the entity before saving to outbox.
   * Now also receives the previous state (before).
   */
  preparePayload(entity: T, before?: T | null): any {
    return {
      before: before || {},
      after: entity || {},
    };
  }

  async afterInsert(event: InsertEvent<T>) {
    await this.handleEvent(event.metadata.name, null, event.entity, "created");
  }

  async afterUpdate(event: UpdateEvent<T>) {
    if (event.entity) {
      await this.handleEvent(
        event.metadata.name,
        event.databaseEntity,
        event.entity as T,
        "updated",
      );
    }
  }

  async afterRemove(event: any) {
    if (event.entity) {
      await this.handleEvent(
        event.metadata.name,
        event.entity,
        null,
        "deleted",
      );
    }
  }

  async afterSoftRemove(event: any) {
    if (event.entity) {
      await this.handleEvent(
        event.metadata.name,
        event.databaseEntity,
        event.entity,
        "deleted",
      );
    }
  }

  private async handleEvent(
    entityName: string,
    before: T | null,
    after: T | null,
    action: "created" | "updated" | "deleted",
  ) {
    // Recursion Guard: Ignore outbox transitions to avoid infinite loops
    if (entityName === "OutboxEntity" || entityName === "OutboxIntEntity") {
      return;
    }

    // Dynamic Guard: Ignore entities explicitly excluded in configuration
    const options = (this.outboxService as any).options;
    const isExcluded = options?.excludedEntities?.some((excluded: any) => {
      if (typeof excluded === "string") return excluded === entityName;
      if (typeof excluded === "function") return excluded.name === entityName;
      return false;
    });

    if (isExcluded) {
      return;
    }

    const targetEntity = after || before;
    if (!targetEntity) return;

    const topic = (this.outboxService as any).options?.topic;

    if (!topic) {
      this.logger.error(
        "Kafka topic is not defined in KafkaOutboxModule options",
      );
      return;
    }

    const eventType = this.getEventType(entityName, targetEntity as T, action);
    const key = this.getKey(targetEntity as T);

    const eventData = this.preparePayload(after as T, before);

    const finalPayload = {
      topic,
      event_type: eventType,
      event_time: new Date().toISOString(),
      event_data: eventData,
    };

    if (this.outboxService["options"]?.enableLog !== false) {
      this.logger.debug(
        `Relaying entity change to outbox: topic=${topic}, eventType=${eventType}, key=${key}`,
      );
    }
    await this.outboxService.emit(topic, finalPayload, key);
  }
}
