import { OutboxEntry } from "./outbox-entry.interface";

export interface IOutboxRepository {
  save(
    entry: Omit<OutboxEntry, "id" | "status" | "createdAt" | "attempts">,
  ): Promise<OutboxEntry>;
  findPending(limit: number): Promise<OutboxEntry[]>;
  updateStatus(
    id: string | number,
    status: OutboxEntry["status"],
    error?: string,
  ): Promise<void>;
  deleteProcessed(olderThanDays: number): Promise<void>;
}

export const IOutboxRepository = Symbol("IOutboxRepository");
